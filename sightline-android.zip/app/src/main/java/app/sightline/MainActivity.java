package app.sightline;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(60, 60, 60, 60);
        l.setBackgroundColor(0xFFEEF3F1);

        TextView t = new TextView(this);
        t.setText("Sightline");
        t.setTextSize(34);
        t.setTextColor(0xFF12303A);
        t.setGravity(Gravity.CENTER);
        l.addView(t);

        TextView d = new TextView(this);
        d.setText("চোখ ও ঘাড় রক্ষক\n\nচালু করলে স্ক্রিনের কোণায় একটা ছোট বাক্স ভাসবে। অন্য অ্যাপে গেলেও ঘাড়ের কোণ, পলক আর চোখের বিরতি দেখাবে ও শব্দ করবে। বাক্সটা আঙুলে টেনে সরানো যায়।");
        d.setTextSize(16);
        d.setTextColor(0xFF5D7780);
        d.setGravity(Gravity.CENTER);
        d.setPadding(0, 30, 0, 50);
        l.addView(d);

        Button go = new Button(this);
        go.setText("চালু করো");
        go.setOnClickListener(v -> start());
        l.addView(go);

        Button stop = new Button(this);
        stop.setText("বন্ধ করো");
        stop.setOnClickListener(v -> stopService(new Intent(this, HudService.class)));
        l.addView(stop);

        setContentView(l);
    }

    void start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "\"অন্য অ্যাপের ওপরে দেখানো\" অনুমতি চালু করে ফিরে এসো", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        Intent i = new Intent(this, HudService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        Toast.makeText(this, "চালু হয়েছে", Toast.LENGTH_SHORT).show();
    }
}
