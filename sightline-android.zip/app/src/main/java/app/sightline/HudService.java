package app.sightline;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Icon;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import java.util.Locale;

public class HudService extends Service implements SensorEventListener {
    static final String CH = "sightline";
    WindowManager wm;
    HudView hud;
    WindowManager.LayoutParams lp;
    SensorManager sm;
    Handler h = new Handler(Looper.getMainLooper());
    TextToSpeech tts;
    boolean ttsOk = false;
    PowerManager.WakeLock wl;

    float gx, gy, gz;
    boolean hasData = false;
    float bend = 0, dBend = 0;
    long nextBreak, breakEnd, blinkAt, lastAlert, lastTick;
    boolean onBreak = false, wasBad = false;
    int goodStreak = 0;
    float sx, sy;
    int ox, oy;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && "STOP".equals(i.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (hud == null) begin();
        return START_STICKY;
    }

    Notification buildNote() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Sightline", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CH);
        } else {
            b = new Notification.Builder(this);
        }
        Intent si = new Intent(this, HudService.class).setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 0, si, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        b.setContentTitle("Sightline চলছে")
                .setContentText("ঘাড় ও চোখ পাহারা দিচ্ছি")
                .setSmallIcon(R.drawable.ic_launcher)
                .setOngoing(true);
        b.addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_launcher), "বন্ধ করো", pi).build());
        return b.build();
    }

    void begin() {
        startForeground(1, buildNote());
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        float d = getResources().getDisplayMetrics().density;
        int w = (int) (150 * d), hh = (int) (84 * d);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(w, hh, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = getResources().getDisplayMetrics().widthPixels - w - (int) (8 * d);
        lp.y = (int) (90 * d);
        hud = new HudView(this);
        hud.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lp.x = (int) (ox + e.getRawX() - sx);
                    lp.y = (int) (oy + e.getRawY() - sy);
                    wm.updateViewLayout(hud, lp);
                    return true;
            }
            return false;
        });
        wm.addView(hud, lp);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sightline:wl");
        wl.acquire();

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        Sensor acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("bn", "BD"));
                ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });

        long now = System.currentTimeMillis();
        nextBreak = now + 1200000;
        blinkAt = now;
        lastTick = now;
        beep(60, ToneGenerator.TONE_PROP_ACK, 200);
        h.postDelayed(() -> speak("শুরু হলো। প্রতি ২০ মিনিট পরপর আমি তোমাকে দূরে তাকাতে বলব"), 1500);
        h.post(loop);
    }

    final Runnable loop = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            dBend += (bend - dBend) * 0.25f;
            if (now - lastTick >= 1000) {
                lastTick = now;
                logic(now);
            }
            int left = (int) Math.max(0, (nextBreak - now) / 1000);
            int bl = (int) Math.max(0, (breakEnd - now + 999) / 1000);
            hud.upd(dBend, left, onBreak, bl, now - blinkAt, hasData);
            hud.invalidate();
            h.postDelayed(this, 100);
        }
    };

    void logic(long now) {
        if (onBreak) {
            if (now >= breakEnd) {
                onBreak = false;
                nextBreak = now + 1200000;
                chime();
                speak("বিরতি শেষ। আবার ২০ মিনিট পরে বলব");
            }
            return;
        }
        if (hasData) {
            if (bend > 30) {
                goodStreak = 0;
                wasBad = true;
                float vol = 0.15f + 0.85f * Math.min(1f, (bend - 30) / 30f);
                boolean strong = bend > 45;
                long gap = strong ? 2000 : 4000;
                if (now - lastAlert >= gap) {
                    lastAlert = now;
                    beep(Math.round(vol * 100), strong ? ToneGenerator.TONE_PROP_BEEP2 : ToneGenerator.TONE_PROP_BEEP, 300);
                    if (strong) vibrate();
                }
            } else {
                goodStreak++;
                if (wasBad && goodStreak >= 2) {
                    wasBad = false;
                    chime();
                    speak("ঘাড় সোজা হয়েছে, ভালো");
                }
            }
        }
        if (now - blinkAt >= 20000) {
            blinkAt = now;
            beep(8, ToneGenerator.TONE_PROP_BEEP, 60);
        }
        if (now >= nextBreak) {
            onBreak = true;
            breakEnd = now + 20000;
            chime();
            vibrate();
            speak("এখন ২০ সেকেন্ড দূরে তাকাও");
        }
    }

    void beep(int vol, int tone, int ms) {
        try {
            final ToneGenerator t = new ToneGenerator(AudioManager.STREAM_MUSIC, Math.max(1, Math.min(100, vol)));
            t.startTone(tone, ms);
            h.postDelayed(t::release, ms + 200);
        } catch (Exception e) { }
    }

    void chime() { beep(60, ToneGenerator.TONE_PROP_ACK, 250); }

    void speak(String s) {
        if (ttsOk) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "s");
    }

    void vibrate() {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v != null) v.vibrate(150);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (!hasData) {
            gx = e.values[0]; gy = e.values[1]; gz = e.values[2];
        } else {
            gx = gx * 0.8f + e.values[0] * 0.2f;
            gy = gy * 0.8f + e.values[1] * 0.2f;
            gz = gz * 0.8f + e.values[2] * 0.2f;
        }
        hasData = true;
        double p = Math.toDegrees(Math.atan2(Math.abs(gy), Math.abs(gz) + 0.001));
        bend = (float) (90 - Math.max(0, Math.min(90, p)));
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) { }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (sm != null) sm.unregisterListener(this);
        if (hud != null && wm != null) {
            try { wm.removeView(hud); } catch (Exception e) { }
        }
        if (tts != null) tts.shutdown();
        if (wl != null && wl.isHeld()) wl.release();
        stopForeground(true);
        super.onDestroy();
    }

    static String bn(String s) {
        String d = "০১২৩৪৫৬৭৮৯";
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) b.append(c >= '0' && c <= '9' ? d.charAt(c - '0') : c);
        return b.toString();
    }

    static class HudView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF oval = new RectF(30, 68, 130, 168);
        RectF bg = new RectF(0, 0, 300, 168);
        float bend; int left; boolean brk; int brkLeft; long since; boolean has;

        HudView(Context c) { super(c); }

        void upd(float b, int l, boolean bk, int bl, long s, boolean hs) {
            bend = b; left = l; brk = bk; brkLeft = bl; since = s; has = hs;
        }

        void txt(Canvas c, String s, float x, float y, float size, int col, Paint.Align al) {
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(size);
            p.setColor(col);
            p.setTextAlign(al);
            c.drawText(s, x, y, p);
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = getWidth() / 300f;
            c.save();
            c.scale(s, s);
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, 0, 300, 168, 0xFF0D2A33, 0xFF154452, Shader.TileMode.CLAMP));
            c.drawRoundRect(bg, 26, 26, p);
            p.setShader(null);

            int col = bend > 45 ? 0xFFFF6B57 : bend > 30 ? 0xFFF1B52C : 0xFF2FD1A0;
            txt(c, "Sightline", 16, 24, 12, 0xB3FFFFFF, Paint.Align.LEFT);

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(13);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0x26FFFFFF);
            c.drawArc(oval, 180, 180, false, p);
            if (bend > 1) {
                p.setColor(col);
                c.drawArc(oval, 180, 180f * Math.min(1f, bend / 90f), false, p);
            }
            txt(c, bn(String.valueOf(Math.round(bend))) + "°", 80, 116, 30, 0xFFFFFFFF, Paint.Align.CENTER);
            String st = !has ? "সেন্সর নেই" : bend > 45 ? "সোজা করো!" : bend > 30 ? "একটু ঝুঁকে" : "ভঙ্গি ভালো";
            txt(c, st, 80, 152, 13, col, Paint.Align.CENTER);

            txt(c, "পরের বিরতি", 160, 44, 12, 0xB3FFFFFF, Paint.Align.LEFT);
            String tm = String.format(Locale.US, "%02d:%02d", left / 60, left % 60);
            txt(c, bn(tm), 160, 80, 30, 0xFFFFFFFF, Paint.Align.LEFT);

            float o = 1f;
            if (since < 350) o = (float) (0.08 + 0.92 * Math.abs(Math.cos(since / 350.0 * Math.PI)));
            float ex = 186, ey = 126;
            if (since < 2500) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(3);
                p.setColor(((int) (150 * (1 - since / 2500f)) << 24) | 0x2FD1A0);
                c.drawCircle(ex, ey, 22 + since / 100f, p);
            }
            Path eye = new Path();
            eye.moveTo(ex - 24, ey);
            eye.quadTo(ex, ey - 20 * o, ex + 24, ey);
            eye.quadTo(ex, ey + 20 * o, ex - 24, ey);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFFFFF);
            c.drawPath(eye, p);
            p.setColor(0xFF12303A);
            c.drawCircle(ex, ey, 7 * o, p);
            String bt = since < 2500 ? "পলক!" : "পলক " + bn(String.valueOf(Math.max(0, 20 - since / 1000)));
            txt(c, bt, 222, 131, 13, since < 2500 ? 0xFF2FD1A0 : 0xFFFFFFFF, Paint.Align.LEFT);

            if (brk) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xF50D2A33);
                c.drawRoundRect(bg, 26, 26, p);
                txt(c, "দূরে তাকাও", 150, 80, 28, 0xFFFFFFFF, Paint.Align.CENTER);
                txt(c, bn(String.valueOf(brkLeft)) + " সেকেন্ড", 150, 120, 22, 0xFF2FD1A0, Paint.Align.CENTER);
            }
            c.restore();
        }
    }
}
